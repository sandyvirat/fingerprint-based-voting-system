# fingerprint-based-voting-system
A basic voting machine demo on python with r305 fingerprint scanner.
